 
export default function PartnerReferralProgram() {
    return (
        <section>
            partner-referral-program
        </section>
    );
}
