import HeroSection from "./HeroSection/HeroSection"; 
import Breadcrumb from "../../components/breadcrumb/BreadcrumbSec";
export default function Pricing() {
  return (
    <>
      <Breadcrumb /> 
      <HeroSection /> 
    </>
  );
}
